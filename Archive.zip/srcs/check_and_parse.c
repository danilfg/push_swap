/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_and_parse.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: taegon-i <taegon-i@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/22 13:48:52 by taegon-i          #+#    #+#             */
/*   Updated: 2020/01/22 15:27:12 by taegon-i         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <push_swap.h>

void	parse_array(t_stack_all *stack, int argc, char **argv)
{
	int i;

	i = 1;
	while (i < argc)
	{
		if (!ft_isint(argv[i], false))
			error_message(4);
		add(stack, create_elem(ft_atoi(argv[i++])));
	}
}

t_stack		*create_elem(int number)
{
	t_stack	*new;

	if (!(new = (t_stack *)ft_memalloc(sizeof(t_stack))))
		error_message(3);
	new->value = number;
	new->index = -1;
	new->previous = NULL;
	new->next = NULL;
	return (new);
}

void		add_in_stack(t_stack_all *stack, t_stack *elem)
{
	t_stack	*tmp;

	if (stack && elem)
	{
		if (!stack->a_stack)
		{
			stack->a_stack = elem;
			stack->a_stack->previous = stack->a_stack;
			stack->a_stack->next = stack->a_stack;
		}
		else
		{
			tmp = stack->a_stack->previous;
			elem->previous = tmp;
			tmp->next = elem;
			elem->next = stack->a_stack;
			stack->a_stack->previous = elem;
		}
		stack->a_size++;
	}
}

void	parse_string(t_stack_all *stack, char *str)
{
	char	**numbers;
	size_t	i;


	numbers = ft_strsplit(str, ' ');
	i = 0;
	while (numbers[i])
	{
		if (!ft_isint(numbers[i], false))
			error_message(4);
		add_in_stack(stack, create_elem(ft_atoi(numbers[i++])));
	}
	ft_strsplit_free(&numbers);
}


t_stack_all	*contain_in_a(int argc, char *argv[])
{
	t_stack_all *stack;
	int		i;
	int		index;
	int		j;


	if (!(stack = (t_stack_all *)ft_memalloc(sizeof(t_stack_all))))
		error_message(3);
	stack->a_stack = NULL;
	stack->a_size = 0;
	i = 0;
	if (argc == 2)
		parse_string(stack, argv[1]);
	else
		parse_array(stack, argc, argv);
	if (!stack->a_size)
		error_message(2);;
	return (stack);
}
